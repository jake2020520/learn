<template>
  <div>
    <r-icon name="gou1"></r-icon>
    <r-icon name="loading"></r-icon>

  </div>
</template>

<script>
export default {};
</script>

<style scoped>
</style>