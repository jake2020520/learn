## 注意

- 忘记写组件的 name
- 忘记写组件的props
- 忘记在main.js 中引入 组件
- 要记得 class的命名