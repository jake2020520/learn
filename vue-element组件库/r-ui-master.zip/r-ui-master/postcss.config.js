module.exports = {
  plugins: {
    // 这个工具可以实现自动添加CSS3前缀
		"autoprefixer": {}
  }
}