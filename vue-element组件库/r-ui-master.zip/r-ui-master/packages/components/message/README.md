## TODO

- [ ] 可以创建多个，计算各自的位置
- [ ] 可以自动关闭和手动关闭
- [ ] 三个位置，左中右
- [ ] 可以叠加
- [ ] 入场出厂动画
- [ ] 可关闭


## 遇到的问题

- [x]怎么也获取不到 每一个message 组件的offsetHeight值 (原因是 在message。vue的template中 多了一层无用的 div，导致 offsetHeight为0)

- [ ] scss文件中 没办法用 mixin和注释