## TODO 

- [ ] 编写html和css
- [ ] 编写js
- [ ] 确定props
- [ ] $attrs, $listeners
- [ ] inheritAttrs
- [ ] 数据双向绑定
- [ ] 文本域textarea
- [ ] clearable
- [ ] disabled
- [ ] 前后缀 
- [ ] 尺寸

## 疑问

$listeners 有啥用

## 重写过程报错

```js
vue.runtime.esm.js:620 [Vue warn]: Invalid prop: type check failed for prop "value". Expected Number, String, got InputEvent 
```