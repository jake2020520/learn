## TODO

- [x] 使用场景 https://www.jianshu.com/p/d092992b6473
- [x] html和样式
- [x] js编写
- [x] 结合animate。css实现出场入场动画
- [x] 传递参数给 组件，组件传递参数给父亲
- [x] 关闭，成功，失败，回调函数