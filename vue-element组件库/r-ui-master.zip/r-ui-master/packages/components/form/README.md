## TODO

- [ ] html 和 css 编写
- [ ] js 编写
- [ ] 确定 props
- [ ] 排版布局
- [ ] 表单校验

## 问题

1. provide 和 inject 不会用
2. checkbox 多个时，布局有问题

做的过程中 回报什么 `transform` 的错，是因为 descriptor 需要把没有校验的项 赋值 `{}`
