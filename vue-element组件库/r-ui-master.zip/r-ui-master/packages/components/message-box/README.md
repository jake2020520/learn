## TODO

- [ ] 编写html，css
- [ ] 编写js
- [ ] 确定 props
- [ ] 动画transition
- [ ] 取消和 确定按钮的回调好函数
- [ ] 控制是alert还是confirm