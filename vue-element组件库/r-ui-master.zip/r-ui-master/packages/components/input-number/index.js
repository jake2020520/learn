import InputNumber from './index.vue';

InputNumber.install = function (Vue) {
  Vue.component (InputNumber.name, InputNumber);
};

export default InputNumber;
