import FormItem from './index.vue';

FormItem.install = function (Vue) {
  Vue.component (FormItem.name, FormItem);
};

export default FormItem;
