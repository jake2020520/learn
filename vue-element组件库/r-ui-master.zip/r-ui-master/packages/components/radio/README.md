## TODO

- [x] html 和 css 样式
- [x] js 编写
- [x] radioGroup


参考 
https://jdc.jd.com/archives/4681